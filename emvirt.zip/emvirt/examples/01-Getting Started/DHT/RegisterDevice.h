#ifndef RegisterDevice_h
#define RegisterDevice_h
#include <Arduino.h>
#include <Preferences.h>

String devid; //deviceid for emv
Preferences preferences;
void sendRegisterDevice(const char* userID) {
  //Serial.println("Posting JSON data to server...");
  // Block until we are able to connect to the WiFi access point

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http; 
      
    //http.begin("http://192.168.1.6:32000/register_device/");  
    http.begin("http://api.emvirtcloud.com/register_device/");
    http.addHeader("Content-Type", "application/json");         
     
    StaticJsonDocument<200> doc;
    // Add values in the document
    doc["user_id"] = userID;
    JsonObject mac_addresses  = doc.createNestedObject("mac_addresses");
    mac_addresses["wlan0"] = WiFi.macAddress();
    
    String requestBody;
    serializeJson(doc, requestBody);  
    //Serial.println(requestBody);
    int httpResponseCode = http.POST(requestBody);
 
    //if(httpResponseCode>0){
       
      String response = http.getString();                       
      //Serial.println(httpResponseCode);
      //Serial.println(response);

      StaticJsonDocument<50> doc1;
      deserializeJson(doc1, response);
      JsonObject obj = doc1.as<JsonObject>();
      String d=obj[String("device_id")];
      devid = d;

      preferences.begin("emvAgentPrefs", false);
      preferences.putString("devid", devid); 
      preferences.end();
      //Serial.println("Yeah! Your device is registered successfully:)");
      //Serial.println(devid);
    /*}
    else {
      Serial.println("Error occurred while registeration of your device...");
      Serial.println("Wait! EMV restart your device...");
      ESP.restart();
    }*/
    http.end();
  }
}

#endif
